# CinderKit

A minimal static site starter for landing pages and quick projects. No build step, no dependencies, no framework. Clone, edit, ship.

## Philosophy

- **Start small.** Just enough structure to move fast.
- **Logo first.** Drop in your mark, pull colors from there.
- **No magic.** Plain HTML, CSS, and optional JS. You own every line.

## Structure

```
cinderkit/
├── index.html        # Full LP template with all sections
├── styles.css        # CSS variables, components, dark/light mode
├── main.js           # Nav, modal, toast, scroll animations, form protection
├── robots.txt        # Search engine directives
├── sitemap.xml       # Sitemap template
├── assets/
│   ├── logo.svg      # Logo placeholder
│   ├── favicon.svg   # Favicon placeholder
│   ├── og-image.svg  # Social sharing image placeholder
│   └── screenshot.svg # Screenshot placeholder
└── README.md
```

## Quick Start

1. Clone or download
2. Replace `assets/logo.svg` with your logo
3. Update colors in `:root` variables in `styles.css`
4. Edit content in `index.html`
5. Update `sitemap.xml` and `robots.txt` with your domain
6. Deploy to GitHub Pages, Netlify, or anywhere static

## Included Sections

- **Hero** — headline, subhead, CTA button
- **Value proposition** — simple text section
- **Features grid** — 4-card responsive grid with icons
- **Testimonial** — styled blockquote
- **How it works** — numbered steps
- **FAQ** — accordion (pure CSS, no JS required)
- **Screenshot** — centered image with caption
- **Pricing** — 4-tier card grid with featured highlight
- **CTA** — email signup with form

## Components

### Cards
```html
<div class="card">
  <div class="card-icon">⚡</div>
  <h3>Title</h3>
  <p>Description</p>
</div>
```

### Badges
```html
<span class="badge badge-accent">New</span>
<span class="badge badge-success">Active</span>
<span class="badge badge-warning">Pending</span>
<span class="badge badge-error">Expired</span>
```

### Buttons
```html
<a href="#" class="button">Primary</a>
<a href="#" class="button button-outline">Outline</a>
<a href="#" class="button button-small">Small</a>
```

### Modal
Add `data-modal-open="modal"` to any element to trigger the modal:
```html
<button data-modal-open="modal">Open Modal</button>
```
Closes via X button, overlay click, or Escape key.

### Toast Notifications
```javascript
showToast('Message here', 'info');    // info, success, or error
showToast('Saved!', 'success', 5000); // custom duration in ms
```

## Forms

Three form patterns included:
1. **Email signup** — inline email + submit (active in CTA)
2. **Contact form** — name, email, message (commented out)
3. **Multi-field form** — full registration style (commented out)

All forms include spam protection:
- Honeypot field (hidden, bots fill it)
- Time-based check (rejects submissions under 2 seconds)

Replace `YOUR_FORM_ID` with your Formspree, Netlify, or Basin endpoint.

## Theming

Light/dark mode is automatic via `prefers-color-scheme`. 

### Color Variables
```css
--color-bg         /* Page background */
--color-surface    /* Cards, inputs */
--color-text       /* Primary text */
--color-text-muted /* Secondary text */
--color-accent     /* Links, buttons */
--color-border     /* Borders, dividers */
```

## Accessibility

- Semantic HTML throughout
- Visible focus states
- `prefers-reduced-motion` respected for animations
- Keyboard-navigable modal (Escape to close)
- Skip link ready (add if needed)

## SEO

- Meta tags for title, description, OG/Twitter cards
- JSON-LD structured data (WebSite schema, LocalBusiness commented)
- `robots.txt` and `sitemap.xml` templates included

## Browser Support

Modern browsers (Chrome, Firefox, Safari, Edge). No IE11 support.

## License

Do whatever you want with it.
