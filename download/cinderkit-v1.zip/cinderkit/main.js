/* ================================
   CinderKit JS
   Optional. Delete if not needed.
   ================================ */

// --- Mobile Navigation Toggle ---
const navToggle = document.querySelector('.nav-toggle');
const navMenu = document.querySelector('.nav-menu');

navToggle?.addEventListener('click', () => {
  const isOpen = navToggle.getAttribute('aria-expanded') === 'true';
  navToggle.setAttribute('aria-expanded', !isOpen);
  navMenu.classList.toggle('is-open');
});

// Close menu when clicking a link
navMenu?.querySelectorAll('a').forEach(link => {
  link.addEventListener('click', () => {
    navToggle.setAttribute('aria-expanded', 'false');
    navMenu.classList.remove('is-open');
  });
});

// --- Back to Top Button ---
const backToTop = document.querySelector('.back-to-top');

window.addEventListener('scroll', () => {
  if (window.scrollY > 300) {
    backToTop?.classList.add('is-visible');
  } else {
    backToTop?.classList.remove('is-visible');
  }
});

// --- Modal ---
const modal = document.getElementById('modal');
const modalCloseBtns = document.querySelectorAll('.modal-close, [data-modal-close]');

// Open modal: Add data-modal-open="modal" to any trigger element
document.querySelectorAll('[data-modal-open]').forEach(trigger => {
  trigger.addEventListener('click', (e) => {
    e.preventDefault();
    const targetId = trigger.getAttribute('data-modal-open');
    const targetModal = document.getElementById(targetId);
    targetModal?.classList.add('is-open');
    document.body.style.overflow = 'hidden';
  });
});

// Close modal
modalCloseBtns.forEach(btn => {
  btn.addEventListener('click', () => {
    modal?.classList.remove('is-open');
    document.body.style.overflow = '';
  });
});

// Close on overlay click
modal?.addEventListener('click', (e) => {
  if (e.target === modal) {
    modal.classList.remove('is-open');
    document.body.style.overflow = '';
  }
});

// Close on Escape key
document.addEventListener('keydown', (e) => {
  if (e.key === 'Escape' && modal?.classList.contains('is-open')) {
    modal.classList.remove('is-open');
    document.body.style.overflow = '';
  }
});

// --- Toast Notifications ---
function showToast(message, type = 'info', duration = 3000) {
  const container = document.getElementById('toast-container');
  if (!container) return;

  const toast = document.createElement('div');
  toast.className = `toast toast-${type}`;
  toast.textContent = message;
  container.appendChild(toast);

  setTimeout(() => {
    toast.classList.add('is-leaving');
    toast.addEventListener('animationend', () => toast.remove());
  }, duration);
}

// Example usage (uncomment to test):
// showToast('This is an info message', 'info');
// showToast('Success! It worked.', 'success');
// showToast('Something went wrong.', 'error');

// --- Scroll Animations (IntersectionObserver) ---
const fadeElements = document.querySelectorAll('.fade-in');

const fadeObserver = new IntersectionObserver((entries) => {
  entries.forEach(entry => {
    if (entry.isIntersecting) {
      entry.target.classList.add('is-visible');
      fadeObserver.unobserve(entry.target); // Only animate once
    }
  });
}, {
  threshold: 0.1,
  rootMargin: '0px 0px -50px 0px'
});

fadeElements.forEach(el => fadeObserver.observe(el));

// --- Form Spam Protection ---
// Honeypot is handled via CSS (hidden field that bots fill)
// Time-based check: forms submitted too fast are likely bots
document.querySelectorAll('[data-form-time]').forEach(form => {
  const loadedField = form.querySelector('input[name="_form_loaded"]');
  if (loadedField) {
    loadedField.value = Date.now();
  }
  
  form.addEventListener('submit', (e) => {
    // Check honeypot
    const honeypot = form.querySelector('.honeypot');
    if (honeypot && honeypot.value) {
      e.preventDefault();
      return false;
    }
    
    // Check time (reject if submitted in less than 2 seconds)
    if (loadedField && loadedField.value) {
      const loadTime = parseInt(loadedField.value, 10);
      const submitTime = Date.now();
      if (submitTime - loadTime < 2000) {
        e.preventDefault();
        showToast('Please wait a moment before submitting.', 'error');
        return false;
      }
    }
  });
});

// --- Theme Toggle (if you want manual control) ---
// Uncomment and add a button with id="theme-toggle" to use

/*
const toggle = document.getElementById('theme-toggle');
const root = document.documentElement;

toggle?.addEventListener('click', () => {
  const current = root.getAttribute('data-theme');
  const next = current === 'dark' ? 'light' : 'dark';
  root.setAttribute('data-theme', next);
  localStorage.setItem('theme', next);
});

// Check for saved preference
const saved = localStorage.getItem('theme');
if (saved) {
  root.setAttribute('data-theme', saved);
}
*/

// --- Smooth Scroll (for anchor links) ---
// Uncomment if you have in-page navigation

/*
document.querySelectorAll('a[href^="#"]').forEach(anchor => {
  anchor.addEventListener('click', (e) => {
    e.preventDefault();
    const target = document.querySelector(anchor.getAttribute('href'));
    target?.scrollIntoView({ behavior: 'smooth' });
  });
});
*/

// --- Form Submission Feedback ---
// Basic example for Formspree, customize as needed

/*
const form = document.querySelector('form');
form?.addEventListener('submit', async (e) => {
  e.preventDefault();
  const data = new FormData(form);
  
  try {
    const response = await fetch(form.action, {
      method: 'POST',
      body: data,
      headers: { 'Accept': 'application/json' }
    });
    
    if (response.ok) {
      form.innerHTML = '<p>Thanks! You\'re on the list.</p>';
    } else {
      throw new Error('Form submission failed');
    }
  } catch (error) {
    form.innerHTML = '<p>Something went wrong. Try again later.</p>';
  }
});
*/
